# IT inventara parvaldibas sistema

Spring Boot projekts ar REST API, JWT autentifikaciju, H2 datubazi, Swagger, Docker un vienkarsu front-end (`static` SPA).

## Tehnologijas
- Java 21
- Spring Boot 3.3.8
- Spring Web, Security, Validation, Data JPA
- H2
- JWT (`jjwt`)
- Swagger (`springdoc-openapi`)

## Mapju struktura
```text
src/main/java/lv/valmierastehnikums/Projekts_1
??? config
??? controller
??? dto
?   ??? auth
?   ??? computer
?   ??? employee
?   ??? license
?   ??? user
??? exception
??? model
??? repository
??? security
??? service

src/main/resources
??? application.properties
??? static
    ??? index.html
    ??? app.js
    ??? styles.css
```

## Datubazes shema
- `users(id, username, email, password, role)`
- `employees(id, name, surname, email, phone)`
- `computers(id, model_name, purchase_date, pvz_number, cpu, ram, gpu, hdd, os, status, employee_id)`
- `licenses(id, name, license_key, expiration_date, computer_id)`

Attiecibas:
- `employees (1) -> (N) computers`
- `computers (1) -> (N) licenses`

## JWT konfiguracija
`application.properties`:
- `app.jwt.secret` (Base64 slepena atslega)
- `app.jwt.expiration-ms=86400000`

JWT saturs:
- `sub` = username
- `role` = lietotaja loma

## Security konfiguracija
- Publiski endpointi:
  - `POST /api/auth/register`
  - `POST /api/auth/login`
  - `/swagger-ui/**`, `/v3/api-docs/**`
  - statiskie faili `/`, `/index.html`, `/app.js`, `/styles.css`
- Lomu piekluve:
  - `Users` tikai `ADMIN`
  - `Computers` `ADMIN`, `MANAGER`
  - `Employees GET` visi (`ADMIN`, `MANAGER`, `VIEWER`), `POST` tikai `ADMIN`, `MANAGER`
  - `Licenses GET` visi, `POST/DELETE` `ADMIN`, `MANAGER`

## Endpointi
### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`

### Users (ADMIN)
- `GET /api/users`
- `POST /api/users`
- `PATCH /api/users/{id}/role`
- `DELETE /api/users/{id}`

### Computers (ADMIN, MANAGER)
- `GET /api/computers`
- `GET /api/computers/{id}`
- `POST /api/computers`
- `PUT /api/computers/{id}`
- `DELETE /api/computers/{id}`

### Employees
- `GET /api/employees`
- `GET /api/employees/{id}`
- `POST /api/employees`

### Licenses
- `GET /api/licenses`
- `POST /api/licenses`
- `DELETE /api/licenses/{id}`

## DTO piemers
`ComputerRequest`:
```json
{
  "modelName": "Dell OptiPlex 7090",
  "purchaseDate": "2025-11-10",
  "pvzNumber": "PVZ-2025-001",
  "cpu": "Intel i7",
  "ram": "16GB",
  "gpu": "Intel Iris Xe",
  "hdd": "512GB SSD",
  "os": "Windows 11 Pro",
  "status": "IN_USE",
  "employeeId": 1
}
```

## Request/Response JSON piemers
`POST /api/auth/login` request:
```json
{
  "username": "admin",
  "password": "admin123"
}
```

Response:
```json
{
  "token": "<JWT>",
  "username": "admin",
  "role": "ADMIN"
}
```

## Kluudu piemeri
### 400 Bad Request
```json
{
  "status": 400,
  "error": "Bad Request",
  "message": "Validation failed"
}
```

### 401 Unauthorized
```json
{
  "status": 401,
  "error": "Unauthorized",
  "message": "Authentication required"
}
```

### 403 Forbidden
```json
{
  "status": 403,
  "error": "Forbidden",
  "message": "Access denied"
}
```

### 404 Not Found
```json
{
  "status": 404,
  "error": "Not Found",
  "message": "Computer not found with id: 999"
}
```

### 500 Internal Server Error
```json
{
  "status": 500,
  "error": "Internal Server Error",
  "message": "Unexpected server error"
}
```

## Swagger
- `http://localhost:8080/swagger-ui/index.html`

## Front-end
- `http://localhost:8080/`
- UI atbalsta register/login un datu ieladi (`employees/computers/licenses`) ar JWT.

## Noklusetie lietotaji
- `admin / admin123`
- `manager / manager123`
- `viewer / viewer123`

## Palaist IDE
```bash
./mvnw spring-boot:run
```
Windows:
```powershell
.\mvnw.cmd spring-boot:run
```

## Docker
```bash
docker compose up --build
```

## Testi
```bash
./mvnw test
```
Windows:
```powershell
.\mvnw.cmd test
```
