﻿let token = localStorage.getItem("jwt") || "";
let currentRole = localStorage.getItem("role") || "";
let currentUsername = localStorage.getItem("username") || "";

if (!token) {
  window.location.href = "/auth.html";
}

const authInfo = document.getElementById("authInfo");
const usersCard = document.getElementById("usersCard");
const usersNoAccess = document.getElementById("usersNoAccess");
const usersTabBtn = document.getElementById("usersTabBtn");
const sessionBadge = document.getElementById("sessionBadge");
const rolePill = document.getElementById("rolePill");
const roleBanner = document.getElementById("roleBanner");

const metricUsers = document.getElementById("metricUsers");
const metricEmployees = document.getElementById("metricEmployees");
const metricComputers = document.getElementById("metricComputers");
const metricLicenses = document.getElementById("metricLicenses");

const usersBody = document.getElementById("usersBody");
const employeesBody = document.getElementById("employeesBody");
const computersBody = document.getElementById("computersBody");
const licensesBody = document.getElementById("licensesBody");

const toastHost = document.getElementById("toastHost");
const employeesSearch = document.getElementById("employeesSearch");
const computersSearch = document.getElementById("computersSearch");
const computersStatusFilter = document.getElementById("computersStatusFilter");
const licensesSearch = document.getElementById("licensesSearch");
const employeesCount = document.getElementById("employeesCount");
const computersCount = document.getElementById("computersCount");
const licensesCount = document.getElementById("licensesCount");
const compEmployeeSelect = document.getElementById("compEmployeeSelect");
const licComputerSelect = document.getElementById("licComputerSelect");

const cache = { users: [], employees: [], computers: [], licenses: [] };

const managerOnlySelectors = [
  "#employeesTab .form-grid",
  "#employeesTab .actions",
  "#computersTab .form-grid",
  "#computersTab .actions",
  "#licensesTab .form-grid",
  "#licensesTab .actions"
];

function toggleManagerOnlyControls(hide) {
  managerOnlySelectors.forEach((selector) => {
    document.querySelectorAll(selector).forEach((el) => el.classList.toggle("hidden", hide));
  });
}

function toggleActionColumns(hide) {
  document.querySelectorAll(".action-column").forEach((el) => el.classList.toggle("hidden", hide));
  document.querySelectorAll(".action-cell").forEach((el) => el.classList.toggle("hidden", hide));
}

function setActiveTab(tabId) {
  if (!tabId) return;
  const btn = document.querySelector(`.tab-btn[data-tab='${tabId}']`);
  const panel = document.getElementById(tabId);
  if (!btn || !panel) return;

  document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
  document.querySelectorAll(".tab-panel").forEach((panelEl) => panelEl.classList.add("hidden"));
  btn.classList.add("active");
  panel.classList.remove("hidden");
}

function input(id) {
  return document.getElementById(id).value.trim();
}

function setMetric(el, value) {
  el.textContent = String(value);
}

function tableEmpty(colspan, text) {
  return `<tr><td colspan="${colspan}" class="empty-cell">${text}</td></tr>`;
}

function setStatus(text, error = false) {
  authInfo.textContent = text;
  authInfo.classList.toggle("error", error);
}

function toast(message, error = false) {
  const el = document.createElement("div");
  el.className = `toast ${error ? "error" : ""}`;
  el.textContent = message;
  toastHost.appendChild(el);
  requestAnimationFrame(() => el.classList.add("show"));
  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 200);
  }, 2400);
}

function apiErrorMessage(err) {
  if (!err) return "Nezinama kluda";
  const details = Array.isArray(err.details) && err.details.length ? ` (${err.details.join("; ")})` : "";
  return `${err.message || "Kluda"}${details}`;
}

async function request(path, method = "GET", body) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  const data = text ? (() => { try { return JSON.parse(text); } catch { return null; } })() : null;

  if (!res.ok) {
    if (res.status === 401) {
      localStorage.removeItem("jwt");
      localStorage.removeItem("role");
      localStorage.removeItem("username");
      window.location.href = "/auth.html";
      return null;
    }
    throw new Error(data ? apiErrorMessage(data) : `HTTP ${res.status}`);
  }

  return data;
}

function renderUsers(users) {
  if (!users.length) {
    usersBody.innerHTML = tableEmpty(5, "Nav lietotaju.");
    return;
  }

  usersBody.innerHTML = users.map(u => `
    <tr>
      <td>${u.id}</td>
      <td>${u.username}</td>
      <td>${u.email}</td>
      <td>
        <select data-role-id="${u.id}" ${currentRole !== "ADMIN" ? "disabled" : ""}>
          <option ${u.role === "VIEWER" ? "selected" : ""}>VIEWER</option>
          <option ${u.role === "MANAGER" ? "selected" : ""}>MANAGER</option>
          <option ${u.role === "ADMIN" ? "selected" : ""}>ADMIN</option>
        </select>
      </td>
      <td>
        <button class="mini light" onclick="changeRole(${u.id})">Loma</button>
        <button class="mini danger" onclick="deleteUser(${u.id})">Dzēst</button>
      </td>
    </tr>
  `).join("");
}

function renderEmployees(rows) {
  if (!rows.length) {
    employeesBody.innerHTML = tableEmpty(5, "Nav darbinieku.");
    return;
  }

  employeesBody.innerHTML = rows.map(r => `
    <tr>
      <td>${r.id}</td><td>${r.name}</td><td>${r.surname}</td><td>${r.email}</td><td>${r.phone}</td>
    </tr>
  `).join("");
}

function renderComputers(rows) {
  if (!rows.length) {
    computersBody.innerHTML = tableEmpty(6, "Nav datoru.");
    return;
  }

  const allowActions = currentRole !== "VIEWER";

  computersBody.innerHTML = rows.map(r => `
    <tr>
      <td>${r.id}</td>
      <td>${r.modelName}</td>
      <td>${r.pvzNumber}</td>
      <td><span class="status-chip ${r.status.toLowerCase()}">${r.status}</span></td>
      <td>${r.employeeId ?? "-"}</td>
      <td class="action-cell">${allowActions ? `<button class="mini danger" onclick="deleteComputer(${r.id})">Dzēst</button>` : "-"}</td>
    </tr>
  `).join("");
}

function renderLicenses(rows) {
  if (!rows.length) {
    licensesBody.innerHTML = tableEmpty(6, "Nav licencu.");
    return;
  }

  const allowActions = currentRole !== "VIEWER";

  licensesBody.innerHTML = rows.map(r => `
    <tr>
      <td>${r.id}</td>
      <td>${r.name}</td>
      <td>${r.key}</td>
      <td>${r.expirationDate}</td>
      <td>${r.computerId}</td>
      <td class="action-cell">${allowActions ? `<button class="mini danger" onclick="deleteLicense(${r.id})">Dzēst</button>` : "-"}</td>
    </tr>
  `).join("");
}

function renderLinkedSelectors() {
  const employeeOptions = [
    `<option value="">Darbinieks (optional)</option>`,
    ...cache.employees.map((e) => `<option value="${e.id}">${e.id} - ${e.name} ${e.surname}</option>`)
  ];
  compEmployeeSelect.innerHTML = employeeOptions.join("");

  const computerOptions = [
    `<option value="">Izvelies datoru</option>`,
    ...cache.computers.map((c) => `<option value="${c.id}">${c.id} - ${c.modelName} (${c.pvzNumber})</option>`)
  ];
  licComputerSelect.innerHTML = computerOptions.join("");
}

function applyFiltersAndRender() {
  const empTerm = (employeesSearch.value || "").toLowerCase();
  const compTerm = (computersSearch.value || "").toLowerCase();
  const compStatus = computersStatusFilter.value || "";
  const licTerm = (licensesSearch.value || "").toLowerCase();

  const filteredEmployees = cache.employees.filter((r) =>
    `${r.name} ${r.surname} ${r.email}`.toLowerCase().includes(empTerm)
  );

  const filteredComputers = cache.computers.filter((r) => {
    const textMatch = `${r.modelName} ${r.pvzNumber} ${r.os}`.toLowerCase().includes(compTerm);
    const statusMatch = !compStatus || r.status === compStatus;
    return textMatch && statusMatch;
  });

  const filteredLicenses = cache.licenses.filter((r) =>
    `${r.name} ${r.key}`.toLowerCase().includes(licTerm)
  );

  employeesCount.textContent = String(filteredEmployees.length);
  computersCount.textContent = String(filteredComputers.length);
  licensesCount.textContent = String(filteredLicenses.length);

  renderEmployees(filteredEmployees);
  renderComputers(filteredComputers);
  renderLicenses(filteredLicenses);
}

async function refreshAll() {
  const calls = [request("/api/employees"), request("/api/computers"), request("/api/licenses")];
  if (currentRole === "ADMIN") calls.unshift(request("/api/users"));

  const results = await Promise.all(calls);

  if (currentRole === "ADMIN") {
    const [users, employees, computers, licenses] = results;
    cache.users = users || [];
    cache.employees = employees || [];
    cache.computers = computers || [];
    cache.licenses = licenses || [];

    setMetric(metricUsers, cache.users.length);
    setMetric(metricEmployees, cache.employees.length);
    setMetric(metricComputers, cache.computers.length);
    setMetric(metricLicenses, cache.licenses.length);

    renderUsers(cache.users);
    renderLinkedSelectors();
    applyFiltersAndRender();
  } else {
    const [employees, computers, licenses] = results;
    cache.users = [];
    cache.employees = employees || [];
    cache.computers = computers || [];
    cache.licenses = licenses || [];

    setMetric(metricUsers, 0);
    setMetric(metricEmployees, cache.employees.length);
    setMetric(metricComputers, cache.computers.length);
    setMetric(metricLicenses, cache.licenses.length);

    renderLinkedSelectors();
    applyFiltersAndRender();
  }
}

function applyRoleUi() {
  usersCard.classList.toggle("hidden", currentRole !== "ADMIN");
  usersNoAccess.classList.toggle("hidden", currentRole === "ADMIN");
  usersTabBtn.classList.toggle("hidden", currentRole !== "ADMIN");

  const roleKey = (currentRole || "").toLowerCase();
  document.body.dataset.role = roleKey || "viewer";

  if (token && currentUsername) {
    sessionBadge.textContent = `${currentUsername} • ${currentRole}`;
    sessionBadge.classList.add("ok");
  } else {
    sessionBadge.textContent = "Nav sesijas";
    sessionBadge.classList.remove("ok");
  }

  const activeBtn = document.querySelector(".tab-btn.active");
  if (currentRole !== "ADMIN" && activeBtn?.dataset.tab === "usersTab") {
    setActiveTab("employeesTab");
  }

  const hideManagerControls = currentRole === "VIEWER";
  toggleManagerOnlyControls(hideManagerControls);
  toggleActionColumns(hideManagerControls);

  if (rolePill) {
    rolePill.textContent = currentRole || "NO_ROLE";
    rolePill.className = `role-pill role-${roleKey}`;
  }

  if (roleBanner) {
    const banners = {
      ADMIN: "Admin piekluve: vari parvaldit lietotajus, lomas un visus datus.",
      MANAGER: "Manager piekluve: vari parvaldit darbiniekus, datorus un licences.",
      VIEWER: "Viewer piekluve: lasisanas rezims ar datu apskati bez redigesanas."
    };
    roleBanner.textContent = banners[currentRole] || "Pielagots panelis aktivajai lietotaja lomai.";
  }
}

function clearFields(ids) {
  ids.forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.value = "";
  });
}

function logoutToAuth() {
  localStorage.removeItem("jwt");
  localStorage.removeItem("role");
  localStorage.removeItem("username");
  window.location.href = "/auth.html";
}

async function addUser() {
  await request("/api/users", "POST", {
    username: input("newUsername"),
    email: input("newUserEmail"),
    password: input("newUserPassword"),
    role: input("newUserRole")
  });
  clearFields(["newUsername", "newUserEmail", "newUserPassword"]);
  await refreshAll();
}

async function addEmployee() {
  await request("/api/employees", "POST", {
    name: input("empName"),
    surname: input("empSurname"),
    email: input("empEmail"),
    phone: input("empPhone")
  });
  clearFields(["empName", "empSurname", "empEmail", "empPhone"]);
  await refreshAll();
}

async function addComputer() {
  const employeeRaw = compEmployeeSelect.value;
  await request("/api/computers", "POST", {
    modelName: input("compModel"),
    purchaseDate: input("compDate"),
    pvzNumber: input("compPvz"),
    cpu: input("compCpu"),
    ram: input("compRam"),
    gpu: input("compGpu"),
    hdd: input("compHdd"),
    os: input("compOs"),
    status: input("compStatus"),
    employeeId: employeeRaw ? Number(employeeRaw) : null
  });
  clearFields(["compModel", "compDate", "compPvz", "compCpu", "compRam", "compGpu", "compHdd", "compOs"]);
  compEmployeeSelect.value = "";
  await refreshAll();
}

async function addLicense() {
  const computerRaw = licComputerSelect.value;
  await request("/api/licenses", "POST", {
    name: input("licName"),
    key: input("licKey"),
    expirationDate: input("licDate"),
    computerId: Number(computerRaw)
  });
  clearFields(["licName", "licKey", "licDate"]);
  licComputerSelect.value = "";
  await refreshAll();
}

window.deleteUser = async (id) => {
  if (!confirm(`Dzēst user #${id}?`)) return;
  try {
    await request(`/api/users/${id}`, "DELETE");
    await refreshAll();
    setStatus(`Lietotājs #${id} izdzēsts.`);
    toast(`Lietotājs #${id} izdzēsts.`);
  } catch (e) {
    setStatus(e.message, true);
    toast(e.message, true);
  }
};

window.changeRole = async (id) => {
  const select = document.querySelector(`select[data-role-id='${id}']`);
  if (!select) return;
  try {
    await request(`/api/users/${id}/role`, "PATCH", { role: select.value });
    await refreshAll();
    setStatus(`Lietotajam #${id} uzlikta loma ${select.value}.`);
    toast(`Loma nomainita: ${select.value}`);
  } catch (e) {
    setStatus(e.message, true);
    toast(e.message, true);
  }
};

window.deleteComputer = async (id) => {
  if (!confirm(`Dzēst datoru #${id}?`)) return;
  try {
    await request(`/api/computers/${id}`, "DELETE");
    await refreshAll();
    setStatus(`Dators #${id} izdzēsts.`);
    toast(`Dators #${id} izdzēsts.`);
  } catch (e) {
    setStatus(e.message, true);
    toast(e.message, true);
  }
};

window.deleteLicense = async (id) => {
  if (!confirm(`Dzēst licenci #${id}?`)) return;
  try {
    await request(`/api/licenses/${id}`, "DELETE");
    await refreshAll();
    setStatus(`Licence #${id} izdzēsta.`);
    toast(`Licence #${id} izdzēsta.`);
  } catch (e) {
    setStatus(e.message, true);
    toast(e.message, true);
  }
};

document.getElementById("logoutBtn").onclick = logoutToAuth;
document.getElementById("switchUserBtn").onclick = logoutToAuth;

document.getElementById("refreshBtn").onclick = async () => {
  try {
    await refreshAll();
    setStatus(`Dati atjaunoti (${currentUsername || "nav user"}).`);
  } catch (e) {
    setStatus(`Ielades kluda: ${e.message}`, true);
    toast(e.message, true);
  }
};

document.getElementById("addUserBtn").onclick = async () => {
  try {
    await addUser();
    setStatus("Lietotajs pievienots.");
    toast("Lietotajs pievienots.");
  } catch (e) {
    setStatus(`User kluda: ${e.message}`, true);
    toast(e.message, true);
  }
};

document.getElementById("addEmployeeBtn").onclick = async () => {
  try {
    await addEmployee();
    setStatus("Darbinieks pievienots.");
    toast("Darbinieks pievienots.");
  } catch (e) {
    setStatus(`Employee kluda: ${e.message}`, true);
    toast(e.message, true);
  }
};

document.getElementById("addComputerBtn").onclick = async () => {
  try {
    await addComputer();
    setStatus("Dators pievienots.");
    toast("Dators pievienots.");
  } catch (e) {
    setStatus(`Computer kluda: ${e.message}`, true);
    toast(e.message, true);
  }
};

document.getElementById("addLicenseBtn").onclick = async () => {
  try {
    await addLicense();
    setStatus("Licence pievienota.");
    toast("Licence pievienota.");
  } catch (e) {
    setStatus(`License kluda: ${e.message}`, true);
    toast(e.message, true);
  }
};

[employeesSearch, computersSearch, computersStatusFilter, licensesSearch].forEach((el) => {
  el.addEventListener("input", applyFiltersAndRender);
  el.addEventListener("change", applyFiltersAndRender);
});

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => setActiveTab(btn.dataset.tab));
});

applyRoleUi();
setStatus(`Autentificets: ${currentUsername} (${currentRole})`);
refreshAll().catch((e) => {
  setStatus(`Ielades kluda: ${e.message}`, true);
  toast(e.message, true);
});
