﻿(function () {
  const token = localStorage.getItem("jwt");
  const username = localStorage.getItem("username") || "";
  const role = localStorage.getItem("role") || "";

  const note = document.getElementById("homeNote");
  const dashboardLink = document.getElementById("dashboardLink");

  if (token) {
    note.textContent = `Aktīva sesija: ${username} (${role}). Tu vari uzreiz atvērt pārvaldības paneli.`;
    dashboardLink.setAttribute("href", "/dashboard.html");
    dashboardLink.textContent = "Sākt darbu";
  } else {
    note.textContent = "Lai piekļūtu pārvaldības panelim, vispirms piesakies vai reģistrējies.";
    dashboardLink.setAttribute("href", "/auth.html");
    dashboardLink.textContent = "Sākt darbu";
  }
})();
