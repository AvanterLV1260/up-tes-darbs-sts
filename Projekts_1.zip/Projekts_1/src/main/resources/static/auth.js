let token = localStorage.getItem("jwt") || "";
if (token) {
  window.location.href = "/dashboard.html";
}

const loginTabBtn = document.getElementById("loginTabBtn");
const registerTabBtn = document.getElementById("registerTabBtn");
const loginPanel = document.getElementById("loginPanel");
const registerPanel = document.getElementById("registerPanel");
const authStatus = document.getElementById("authStatus");

function setStatus(text, error = false) {
  authStatus.textContent = text;
  authStatus.classList.toggle("error", error);
}

function apiErrorMessage(err) {
  if (!err) return "Nezinama kluda";
  const details = Array.isArray(err.details) && err.details.length ? ` (${err.details.join("; ")})` : "";
  return `${err.message || "Kluda"}${details}`;
}

function switchTab(tab) {
  const login = tab === "login";
  loginTabBtn.classList.toggle("active", login);
  registerTabBtn.classList.toggle("active", !login);
  loginPanel.classList.toggle("hidden", !login);
  registerPanel.classList.toggle("hidden", login);
}

async function request(path, body) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });

  const text = await res.text();
  const data = text ? (() => { try { return JSON.parse(text); } catch { return null; } })() : null;

  if (!res.ok) {
    throw new Error(data ? apiErrorMessage(data) : `HTTP ${res.status}`);
  }

  return data;
}

function saveSession(data) {
  localStorage.setItem("jwt", data.token);
  localStorage.setItem("role", data.role);
  localStorage.setItem("username", data.username);
}

document.getElementById("loginBtn").onclick = async () => {
  try {
    const data = await request("/api/auth/login", {
      username: document.getElementById("loginUsername").value.trim(),
      password: document.getElementById("loginPassword").value.trim()
    });

    saveSession(data);
    setStatus(`Pieslegts: ${data.username} (${data.role}).`);
    window.location.href = "/dashboard.html";
  } catch (e) {
    setStatus(`Login kluda: ${e.message}`, true);
  }
};

document.getElementById("registerBtn").onclick = async () => {
  try {
    const data = await request("/api/auth/register", {
      username: document.getElementById("registerUsername").value.trim(),
      email: document.getElementById("registerEmail").value.trim(),
      password: document.getElementById("registerPassword").value.trim()
    });

    saveSession(data);
    setStatus(`Konts izveidots: ${data.username} (${data.role}).`);
    window.location.href = "/dashboard.html";
  } catch (e) {
    setStatus(`Register kluda: ${e.message}`, true);
  }
};

loginTabBtn.onclick = () => switchTab("login");
registerTabBtn.onclick = () => switchTab("register");

switchTab("login");
