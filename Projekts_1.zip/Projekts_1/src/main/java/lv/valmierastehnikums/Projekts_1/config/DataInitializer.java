package lv.valmierastehnikums.Projekts_1.config;

import lv.valmierastehnikums.Projekts_1.model.Role;
import lv.valmierastehnikums.Projekts_1.model.User;
import lv.valmierastehnikums.Projekts_1.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initUsers(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            createIfMissing(userRepository, passwordEncoder, "admin", "admin@demo.lv", "admin123", Role.ADMIN);
            createIfMissing(userRepository, passwordEncoder, "manager", "manager@demo.lv", "manager123", Role.MANAGER);
            createIfMissing(userRepository, passwordEncoder, "viewer", "viewer@demo.lv", "viewer123", Role.VIEWER);
        };
    }

    private void createIfMissing(UserRepository userRepository, PasswordEncoder passwordEncoder, String username, String email, String rawPassword, Role role) {
        if (userRepository.existsByUsername(username)) {
            return;
        }

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(rawPassword));
        user.setRole(role);
        userRepository.save(user);
    }
}
