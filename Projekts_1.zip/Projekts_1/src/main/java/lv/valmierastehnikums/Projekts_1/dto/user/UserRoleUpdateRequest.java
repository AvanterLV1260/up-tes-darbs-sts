package lv.valmierastehnikums.Projekts_1.dto.user;

import jakarta.validation.constraints.NotNull;
import lv.valmierastehnikums.Projekts_1.model.Role;

public class UserRoleUpdateRequest {

    @NotNull
    private Role role;

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
}
