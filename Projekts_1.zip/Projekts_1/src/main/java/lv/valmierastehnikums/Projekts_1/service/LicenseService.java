package lv.valmierastehnikums.Projekts_1.service;

import lv.valmierastehnikums.Projekts_1.dto.license.LicenseRequest;
import lv.valmierastehnikums.Projekts_1.dto.license.LicenseResponse;
import lv.valmierastehnikums.Projekts_1.exception.ResourceNotFoundException;
import lv.valmierastehnikums.Projekts_1.model.Computer;
import lv.valmierastehnikums.Projekts_1.model.License;
import lv.valmierastehnikums.Projekts_1.repository.ComputerRepository;
import lv.valmierastehnikums.Projekts_1.repository.LicenseRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LicenseService {

    private final LicenseRepository licenseRepository;
    private final ComputerRepository computerRepository;

    public LicenseService(LicenseRepository licenseRepository, ComputerRepository computerRepository) {
        this.licenseRepository = licenseRepository;
        this.computerRepository = computerRepository;
    }

    public List<LicenseResponse> getAll() {
        return licenseRepository.findAll().stream().map(this::map).toList();
    }

    public LicenseResponse create(LicenseRequest request) {
        Computer computer = computerRepository.findById(request.getComputerId())
                .orElseThrow(() -> new ResourceNotFoundException("Computer not found with id: " + request.getComputerId()));

        License license = new License();
        license.setName(request.getName());
        license.setKey(request.getKey());
        license.setExpirationDate(request.getExpirationDate());
        license.setComputer(computer);

        return map(licenseRepository.save(license));
    }

    public void delete(Long id) {
        if (!licenseRepository.existsById(id)) {
            throw new ResourceNotFoundException("License not found with id: " + id);
        }
        licenseRepository.deleteById(id);
    }

    private LicenseResponse map(License license) {
        return new LicenseResponse(
                license.getId(),
                license.getName(),
                license.getKey(),
                license.getExpirationDate(),
                license.getComputer().getId()
        );
    }
}
