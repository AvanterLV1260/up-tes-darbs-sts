package lv.valmierastehnikums.Projekts_1.controller;

import jakarta.validation.Valid;
import lv.valmierastehnikums.Projekts_1.dto.auth.AuthResponse;
import lv.valmierastehnikums.Projekts_1.dto.auth.LoginRequest;
import lv.valmierastehnikums.Projekts_1.dto.auth.RegisterRequest;
import lv.valmierastehnikums.Projekts_1.service.AuthService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.register(request));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }
}
