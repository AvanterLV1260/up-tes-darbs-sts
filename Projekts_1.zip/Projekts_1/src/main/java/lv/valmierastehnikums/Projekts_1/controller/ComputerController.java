package lv.valmierastehnikums.Projekts_1.controller;

import jakarta.validation.Valid;
import lv.valmierastehnikums.Projekts_1.dto.computer.ComputerRequest;
import lv.valmierastehnikums.Projekts_1.dto.computer.ComputerResponse;
import lv.valmierastehnikums.Projekts_1.service.ComputerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/computers")
public class ComputerController {

    private final ComputerService computerService;

    public ComputerController(ComputerService computerService) {
        this.computerService = computerService;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','VIEWER')")
    public List<ComputerResponse> getAll() {
        return computerService.getAll();
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','VIEWER')")
    public ComputerResponse getById(@PathVariable Long id) {
        return computerService.getById(id);
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<ComputerResponse> create(@Valid @RequestBody ComputerRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(computerService.create(request));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ComputerResponse update(@PathVariable Long id, @Valid @RequestBody ComputerRequest request) {
        return computerService.update(id, request);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        computerService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
