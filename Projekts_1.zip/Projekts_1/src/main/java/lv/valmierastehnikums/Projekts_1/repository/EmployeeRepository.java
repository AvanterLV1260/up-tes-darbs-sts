package lv.valmierastehnikums.Projekts_1.repository;

import lv.valmierastehnikums.Projekts_1.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
}
