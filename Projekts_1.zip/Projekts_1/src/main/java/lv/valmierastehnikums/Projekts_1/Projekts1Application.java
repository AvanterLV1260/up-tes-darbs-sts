package lv.valmierastehnikums.Projekts_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projekts1Application {

	public static void main(String[] args) {
		SpringApplication.run(Projekts1Application.class, args);
	}

}
