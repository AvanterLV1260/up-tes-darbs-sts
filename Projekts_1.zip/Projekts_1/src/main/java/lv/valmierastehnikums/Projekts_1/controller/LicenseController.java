package lv.valmierastehnikums.Projekts_1.controller;

import jakarta.validation.Valid;
import lv.valmierastehnikums.Projekts_1.dto.license.LicenseRequest;
import lv.valmierastehnikums.Projekts_1.dto.license.LicenseResponse;
import lv.valmierastehnikums.Projekts_1.service.LicenseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/licenses")
public class LicenseController {

    private final LicenseService licenseService;

    public LicenseController(LicenseService licenseService) {
        this.licenseService = licenseService;
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','VIEWER')")
    public List<LicenseResponse> getAll() {
        return licenseService.getAll();
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<LicenseResponse> create(@Valid @RequestBody LicenseRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(licenseService.create(request));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        licenseService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
