package lv.valmierastehnikums.Projekts_1.model;

public enum Role {
    ADMIN,
    MANAGER,
    VIEWER
}
