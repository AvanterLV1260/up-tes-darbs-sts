package lv.valmierastehnikums.Projekts_1.repository;

import lv.valmierastehnikums.Projekts_1.model.License;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LicenseRepository extends JpaRepository<License, Long> {
}
