package lv.valmierastehnikums.Projekts_1.dto.computer;

import lv.valmierastehnikums.Projekts_1.model.ComputerStatus;

import java.time.LocalDate;

public class ComputerResponse {
    private Long id;
    private String modelName;
    private LocalDate purchaseDate;
    private String pvzNumber;
    private String cpu;
    private String ram;
    private String gpu;
    private String hdd;
    private String os;
    private ComputerStatus status;
    private Long employeeId;

    public ComputerResponse() {
    }

    public ComputerResponse(Long id, String modelName, LocalDate purchaseDate, String pvzNumber, String cpu, String ram, String gpu, String hdd, String os, ComputerStatus status, Long employeeId) {
        this.id = id;
        this.modelName = modelName;
        this.purchaseDate = purchaseDate;
        this.pvzNumber = pvzNumber;
        this.cpu = cpu;
        this.ram = ram;
        this.gpu = gpu;
        this.hdd = hdd;
        this.os = os;
        this.status = status;
        this.employeeId = employeeId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getPvzNumber() {
        return pvzNumber;
    }

    public void setPvzNumber(String pvzNumber) {
        this.pvzNumber = pvzNumber;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getGpu() {
        return gpu;
    }

    public void setGpu(String gpu) {
        this.gpu = gpu;
    }

    public String getHdd() {
        return hdd;
    }

    public void setHdd(String hdd) {
        this.hdd = hdd;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public ComputerStatus getStatus() {
        return status;
    }

    public void setStatus(ComputerStatus status) {
        this.status = status;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }
}
