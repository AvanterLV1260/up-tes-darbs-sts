package lv.valmierastehnikums.Projekts_1.dto.computer;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lv.valmierastehnikums.Projekts_1.model.ComputerStatus;

import java.time.LocalDate;

public class ComputerRequest {

    @NotBlank
    private String modelName;

    @NotNull
    private LocalDate purchaseDate;

    @NotBlank
    private String pvzNumber;

    @NotBlank
    private String cpu;

    @NotBlank
    private String ram;

    @NotBlank
    private String gpu;

    @NotBlank
    private String hdd;

    @NotBlank
    private String os;

    @NotNull
    private ComputerStatus status;

    private Long employeeId;

    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(LocalDate purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getPvzNumber() {
        return pvzNumber;
    }

    public void setPvzNumber(String pvzNumber) {
        this.pvzNumber = pvzNumber;
    }

    public String getCpu() {
        return cpu;
    }

    public void setCpu(String cpu) {
        this.cpu = cpu;
    }

    public String getRam() {
        return ram;
    }

    public void setRam(String ram) {
        this.ram = ram;
    }

    public String getGpu() {
        return gpu;
    }

    public void setGpu(String gpu) {
        this.gpu = gpu;
    }

    public String getHdd() {
        return hdd;
    }

    public void setHdd(String hdd) {
        this.hdd = hdd;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public ComputerStatus getStatus() {
        return status;
    }

    public void setStatus(ComputerStatus status) {
        this.status = status;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }
}
