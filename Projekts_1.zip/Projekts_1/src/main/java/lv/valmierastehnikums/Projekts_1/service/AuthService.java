package lv.valmierastehnikums.Projekts_1.service;

import lv.valmierastehnikums.Projekts_1.dto.auth.AuthResponse;
import lv.valmierastehnikums.Projekts_1.dto.auth.LoginRequest;
import lv.valmierastehnikums.Projekts_1.dto.auth.RegisterRequest;
import lv.valmierastehnikums.Projekts_1.exception.BadRequestException;
import lv.valmierastehnikums.Projekts_1.model.Role;
import lv.valmierastehnikums.Projekts_1.model.User;
import lv.valmierastehnikums.Projekts_1.repository.UserRepository;
import lv.valmierastehnikums.Projekts_1.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, AuthenticationManager authenticationManager, JwtService jwtService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new BadRequestException("Username already exists");
        }

        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already exists");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(Role.VIEWER);

        User saved = userRepository.save(user);
        String token = jwtService.generateToken(saved, saved.getRole().name());

        return new AuthResponse(token, saved.getUsername(), saved.getRole().name());
    }

    public AuthResponse login(LoginRequest request) {
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
        );

        User user = (User) auth.getPrincipal();
        String token = jwtService.generateToken(user, user.getRole().name());

        return new AuthResponse(token, user.getUsername(), user.getRole().name());
    }
}
