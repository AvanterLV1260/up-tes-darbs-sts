package lv.valmierastehnikums.Projekts_1.dto.license;

import java.time.LocalDate;

public class LicenseResponse {
    private Long id;
    private String name;
    private String key;
    private LocalDate expirationDate;
    private Long computerId;

    public LicenseResponse() {
    }

    public LicenseResponse(Long id, String name, String key, LocalDate expirationDate, Long computerId) {
        this.id = id;
        this.name = name;
        this.key = key;
        this.expirationDate = expirationDate;
        this.computerId = computerId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Long getComputerId() {
        return computerId;
    }

    public void setComputerId(Long computerId) {
        this.computerId = computerId;
    }
}
