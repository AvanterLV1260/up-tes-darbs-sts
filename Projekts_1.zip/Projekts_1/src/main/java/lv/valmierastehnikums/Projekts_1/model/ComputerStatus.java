package lv.valmierastehnikums.Projekts_1.model;

public enum ComputerStatus {
    IN_USE,
    IN_STORAGE,
    IN_REPAIR,
    DISCARDED
}
