package lv.valmierastehnikums.Projekts_1.service;

import lv.valmierastehnikums.Projekts_1.dto.computer.ComputerRequest;
import lv.valmierastehnikums.Projekts_1.dto.computer.ComputerResponse;
import lv.valmierastehnikums.Projekts_1.exception.ResourceNotFoundException;
import lv.valmierastehnikums.Projekts_1.model.Computer;
import lv.valmierastehnikums.Projekts_1.model.Employee;
import lv.valmierastehnikums.Projekts_1.repository.ComputerRepository;
import lv.valmierastehnikums.Projekts_1.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComputerService {

    private final ComputerRepository computerRepository;
    private final EmployeeRepository employeeRepository;

    public ComputerService(ComputerRepository computerRepository, EmployeeRepository employeeRepository) {
        this.computerRepository = computerRepository;
        this.employeeRepository = employeeRepository;
    }

    public List<ComputerResponse> getAll() {
        return computerRepository.findAll().stream().map(this::map).toList();
    }

    public ComputerResponse getById(Long id) {
        Computer computer = computerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Computer not found with id: " + id));
        return map(computer);
    }

    public ComputerResponse create(ComputerRequest request) {
        Computer computer = new Computer();
        apply(computer, request);
        return map(computerRepository.save(computer));
    }

    public ComputerResponse update(Long id, ComputerRequest request) {
        Computer computer = computerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Computer not found with id: " + id));
        apply(computer, request);
        return map(computerRepository.save(computer));
    }

    public void delete(Long id) {
        if (!computerRepository.existsById(id)) {
            throw new ResourceNotFoundException("Computer not found with id: " + id);
        }
        computerRepository.deleteById(id);
    }

    private void apply(Computer computer, ComputerRequest request) {
        computer.setModelName(request.getModelName());
        computer.setPurchaseDate(request.getPurchaseDate());
        computer.setPvzNumber(request.getPvzNumber());
        computer.setCpu(request.getCpu());
        computer.setRam(request.getRam());
        computer.setGpu(request.getGpu());
        computer.setHdd(request.getHdd());
        computer.setOs(request.getOs());
        computer.setStatus(request.getStatus());

        Employee employee = null;
        if (request.getEmployeeId() != null) {
            employee = employeeRepository.findById(request.getEmployeeId())
                    .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + request.getEmployeeId()));
        }

        computer.setEmployee(employee);
    }

    private ComputerResponse map(Computer computer) {
        Long employeeId = computer.getEmployee() != null ? computer.getEmployee().getId() : null;
        return new ComputerResponse(
                computer.getId(),
                computer.getModelName(),
                computer.getPurchaseDate(),
                computer.getPvzNumber(),
                computer.getCpu(),
                computer.getRam(),
                computer.getGpu(),
                computer.getHdd(),
                computer.getOs(),
                computer.getStatus(),
                employeeId
        );
    }
}
