package lv.valmierastehnikums.Projekts_1.repository;

import lv.valmierastehnikums.Projekts_1.model.Computer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComputerRepository extends JpaRepository<Computer, Long> {
}
