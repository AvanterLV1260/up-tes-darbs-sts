package lv.valmierastehnikums.Projekts_1.service;

import lv.valmierastehnikums.Projekts_1.dto.user.UserCreateRequest;
import lv.valmierastehnikums.Projekts_1.dto.user.UserResponse;
import lv.valmierastehnikums.Projekts_1.dto.user.UserRoleUpdateRequest;
import lv.valmierastehnikums.Projekts_1.exception.BadRequestException;
import lv.valmierastehnikums.Projekts_1.exception.ResourceNotFoundException;
import lv.valmierastehnikums.Projekts_1.model.User;
import lv.valmierastehnikums.Projekts_1.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<UserResponse> getAll() {
        return userRepository.findAll()
                .stream()
                .map(this::map)
                .toList();
    }

    public void delete(Long id) {
        if (!userRepository.existsById(id)) {
            throw new ResourceNotFoundException("User not found with id: " + id);
        }
        userRepository.deleteById(id);
    }

    public UserResponse create(UserCreateRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new BadRequestException("Username already exists");
        }
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already exists");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRole(request.getRole());
        return map(userRepository.save(user));
    }

    public UserResponse updateRole(Long id, UserRoleUpdateRequest request) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        user.setRole(request.getRole());
        return map(userRepository.save(user));
    }

    private UserResponse map(User user) {
        return new UserResponse(user.getId(), user.getUsername(), user.getEmail(), user.getRole().name());
    }
}
