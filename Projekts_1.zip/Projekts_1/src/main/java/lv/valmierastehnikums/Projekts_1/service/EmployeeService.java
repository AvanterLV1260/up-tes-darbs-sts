package lv.valmierastehnikums.Projekts_1.service;

import lv.valmierastehnikums.Projekts_1.dto.employee.EmployeeRequest;
import lv.valmierastehnikums.Projekts_1.dto.employee.EmployeeResponse;
import lv.valmierastehnikums.Projekts_1.exception.ResourceNotFoundException;
import lv.valmierastehnikums.Projekts_1.model.Employee;
import lv.valmierastehnikums.Projekts_1.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public List<EmployeeResponse> getAll() {
        return employeeRepository.findAll().stream().map(this::map).toList();
    }

    public EmployeeResponse getById(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with id: " + id));
        return map(employee);
    }

    public EmployeeResponse create(EmployeeRequest request) {
        Employee employee = new Employee();
        employee.setName(request.getName());
        employee.setSurname(request.getSurname());
        employee.setEmail(request.getEmail());
        employee.setPhone(request.getPhone());

        Employee saved = employeeRepository.save(employee);
        return map(saved);
    }

    private EmployeeResponse map(Employee employee) {
        return new EmployeeResponse(employee.getId(), employee.getName(), employee.getSurname(), employee.getEmail(), employee.getPhone());
    }
}
